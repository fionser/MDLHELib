from sys import argv
import numpy as np
def main():
    fname = argv[1]
    M = int(argv[2])
    D = np.genfromtxt(fname, delimiter = ' ')
    mX = M * D[:, :-1]
    Y = D[:, -1]
    XX = mX.T.dot(mX)
    mu = int(max(np.linalg.eigvals(XX)))
    XY = mX.T.dot(Y)
    print mu
    D = np.c_[XX, XY]
    D.astype(int)
    np.savetxt("%s_%d.txt" % (fname, M), D, fmt="%d", delimiter = ' ')

if __name__ == "__main__":
    if len(argv) != 3:
        print "need file and magnifier"
    else:
        main()
